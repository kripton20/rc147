<?php
if (isset($_GET['GET'])== 'test_get'){
	$a="get";
}

if (isset($_POST['POST'])== 'test_post'){
	$a="post";
}

if (isset($_REQUEST['POST'])== 'test_request'){
	$a="request";
}
?>
