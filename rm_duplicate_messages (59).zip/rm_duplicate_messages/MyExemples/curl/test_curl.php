<?php
// создание нового ресурса cURL
$ch = curl_init();

// установка URL и других необходимых параметров
curl_setopt($ch, CURLOPT_URL, "http://localhost/rc147/plugins/rm_duplicate_messages/MyExemples/curl/test_request.php");
curl_setopt($ch, CURLOPT_HEADER, TRUE);
curl_setopt($ch, CURLOPT_VERBOSE, 1);

// Отправим GET - запрос на другую страницу этого сайта с имеющимися куками.
//curl_setopt($ch, CURLOPT_POST, 1); // POST
//curl_setopt($ch, CURLOPT_POSTFIELDS, '_action=plugin.msg_request');

curl_setopt($ch, CURLOPT_HTTPGET, 1); //GET

//curl_setopt($ch, CURLOPT_CUSTOMREQUEST, '_action=plugin.msg_request'); //_action=plugin.msg_request

//curl_setopt($ch, CURLOPT_COOKIEFILE, 'my_cookies.txt');
curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
//curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_REFERER, 'http://localhost/rc147/');
// Убираем вывод данных в браузер. Пусть функция их возвращает а не выводит.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);



// Выполняем запрос curl.
$response = curl_exec($ch);

// после обращения
$curl_info= curl_getinfo($ch);

// завершение сеанса и освобождение ресурсов
curl_close($ch);
?>
