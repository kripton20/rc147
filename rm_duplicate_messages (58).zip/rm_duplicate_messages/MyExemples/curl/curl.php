<?php
// Пользоваетль.
$user        = 'user@domain.com';

Пароль.
$password    = 'password';

// URL для перехода.
$url         = 'http://localhost/rc147/';

// URL для авторизации.
$login_url   = 'http://cadmail:10002/rc147-1/?_task=login';

// параметры для отправки запроса - логин и пароль
$post_data   = 'login=ocik@niiemp.local&password=ocik1905niiemp';

// устанавливаем URL для публикации в
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);

// разрешаем перенаправления
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

// возврат в переменную
curl_setopt($ch, CURLOPT_RETURNTRANSFER,0);

// время ожидания после Ns
curl_setopt($ch, CURLOPT_TIMEOUT, 0);

// установить метод POST
curl_setopt($ch, CURLOPT_POST, 1);

// добавить поля POST
curl_setopt($ch, CURLOPT_POSTFIELDS, '_user=' . $user . '&_pass=' . $password . '&ajax=1&_action=login');

curl_setopt($ch, CURLOPT_FAILONERROR, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);





// создание объекта curl
$ch          = curl_init();

// используем User Agent браузера
$agent       = $_SERVER['HTTP_USER_AGENT'];
$a           = curl_setopt($ch, CURLOPT_USERAGENT, $agent);

// задаем URL
$a           = curl_setopt($ch, CURLOPT_URL, $login_url );

// указываем что это POST запрос
$a           = curl_setopt($ch, CURLOPT_POST, 1 );

// задаем параметры запроса
$a           = curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);

// указываем, чтобы нам вернулось содержимое после запроса
$a           = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// в случае необходимости, следовать по перенаправлени¤м
$a           = curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

/**
* Задаем параметры сохранени¤ cookie
как правило Cookie необходимы для дальнейшей работы с авторизацией
*/

$a           = curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
$a           = curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');

// выполняем запрос для авторизации
$postResult1 = curl_exec($ch);
// Все последующие запросы после успешной авторизации могут выполняться с помощью этих функций (если идентификатор сесии между запросами не поменялся):
$url         = 'http://cadmail:10002/rc147-1/';
$a           = curl_setopt($ch, CURLOPT_URL, $url);
$postResult12= curl_exec($ch);

// закрыть ресурс curl, чтобы освободить системные ресурсы
$a           = curl_close($ch);


?>