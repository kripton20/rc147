<?php
/**
* curl_setopt -- устанавливает параметр для сеанса CURL
* Описание:
* bool curl_setopt ( resource ch, string option, mixed value )
* Функция curl_setopt() Устанавливает параметр для сеанса CURL, заданного аргументом ch.
* Аргумент option задает устанавливаемый параметр, а value - его значение.
*/
// /forum/loginout.php HTTP/1.1
$ch      = curl_init('http://forum.php.su/loginout.php');

// В режиме POST-запрос /forum/..
curl_setopt($ch, CURLOPT_POST, 1);

// User-Agent
curl_setopt ($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (бла бла бла..)');

$headers = array
(
    //'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*;q=0.8',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    'Accept-Encoding: gzip, deflate',
    'Accept-Charset: utf-8,windows-1251;q=0.7,*;q=0.7'
);

// добавляем заголовков к нашему запросу. Чтоб смахивало на настоящих
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// Подделываем значение - откуда пришли данные.
curl_setopt($ch, CURLOPT_REFERER, 'http://forum.php.su/loginout.php');

// POST-данные:// Умная libcurl сама добавит заголовки.// Content - Type: application / x - www - form - urlencoded и Content - Length: 71
curl_setopt($ch, CURLOPT_POSTFIELDS, 'action=login&imembername=kripton20&ipassword=HP1v2HP3v4&submit=%C2%F5%EE%E4');

// Параметры cookiejar и cookiefile:
// Когда сервер выдает нам куки, то есть наклейку - Ты такой-то, он потом смотрит на эту наклейку и вспоминает тебя.
// Но нам для этого разумеется нужно обращаться к серверу когда наклейка у нас висит на видном месте.
// Библиотека libcurl может за нас сохранять наклейку в файл, если мы его укажем в параметре cookiejar и также
// посылать куки, то есть обращаться вместе с наклейкой, если мы укажем файл в котором эту наклейку мы сохранили cookiefile.
// А так как нужно было для авторизации чтоб сервер запомнил что мы, это мы при следующем обращение, то на самом деле нужно было просто получить при авторизации куки. Поэтому вот как мы это сделаем.// Также установлен параметр - без тела (nobody) который говорит что весь html нам не нужен, нужны только заголовки. На самом деле его там и нет, но это только в нашем случае. На самом деле скрипт может и проводить авторизацию и ругаться в одном флаконе.
curl_setopt($ch, CURLOPT_COOKIEJAR, 'my_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'my_cookies.txt');

// Убираем вывод данных в браузер. Пусть функция их возвращает а не выводит.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// true для исключения тела ответа из вывода. Метод запроса устанавливается в HEAD.
// Смена этого параметра в false не меняет его обратно в GET.
//$a8=curl_setopt($ch, CURLOPT_NOBODY, 1);

// true для вывода дополнительной информации.
// Записывает вывод в поток STDERR, или файл, указанный параметром CURLOPT_STDERR.
curl_setopt($ch, CURLOPT_VERBOSE, 1);

// вы можете увидеть информацию о передаче дела перед запросом
// здесь все, что вам нужно:// enable tracking
curl_setopt($ch, CURLINFO_HEADER_OUT, 1);

// do curl request     // request headers
// $headerSent = curl_getinfo($ch, CURLINFO_HEADER_OUT);

// вы также можете использовать CURLOPT_HEADER в своем curl_setopt
curl_setopt($ch, CURLOPT_HEADER, 1);

// Выполняем запрос curl.
$result1 = curl_exec($ch);

// после обращения
$information1 = curl_getinfo($ch);

// Новая инициализация для GET-запроса.
$ch      = curl_init('http://forum.php.su/tools.php?action=rules');

// Отправим GET-запрос на другую страницу этого сайта с имеющимися куками.
curl_setopt($ch, CURLOPT_HTTPGET, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'my_cookies.txt');
curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_REFERER, 'http://forum.php.su/loginout.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);

// Выполняем запрос curl.
$result2 = curl_exec($ch);

// после обращения
$information2 = curl_getinfo($ch);

// Закрываем (удаляем) дескриптор (ресурс).
curl_close($ch);
?>
