<?php
$array = array(
'login' => 'ocik@niiemp.local',
'password' => 'ocik1905niiemp'
);

$ch = curl_init('http://localhost/rc147/?_task=login');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $array);

// Или предать массив строкой:
// curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array, '', '&'));

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HEADER, false);
$html = curl_exec($ch);
curl_close($ch);

echo $html;
//Источник: https://asgeto.ru/zaprosy-curl-v-php-na-primerah
?>