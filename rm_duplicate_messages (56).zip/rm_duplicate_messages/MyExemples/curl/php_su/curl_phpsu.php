<?php
$ch = curl_init('http://php.su');

// Установим опцию "показывать заголовки".
curl_setopt  ($ch, CURLOPT_HEADER, true);

// Получить содержимое в переменную, а в браузер.
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);

curl_exec($ch); // выполняем запрос curl - обращаемся к сервера php.su
/**
* curl_setopt -- Устанавливает параметр для сеанса CURL
* Описание:
* bool curl_setopt ( resource ch, string option, mixed value )
* Функция curl_setopt() Устанавливает параметр для сеанса CURL, заданного аргументом ch.
* Аргумент option задает устанавливаемый параметр, а value - его значение.
*/



curl_close($ch);
?>